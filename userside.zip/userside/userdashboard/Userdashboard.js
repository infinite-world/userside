import React, { Component } from "react";
import {
  MDBCard,
  MDBCardBody,
  MDBCardImage,
  MDBCardTitle,
  MDBCardText,
  MDBRow,
  MDBCol,
  MDBIcon,
} from "mdbreact";
import "./Userdashboard.scss";

class Userdashboard extends Component {
  render() {
    return (
      <div id="user-dashboard-cover-container">
        <div class="container">
          <div class="row">
            <div class="col-sm" style={{ marginBottom: "5%" }}>
              <MDBCol col="4">
                <MDBCard>
                  <MDBCardImage
                    className="purple-gradient white-text d-flex justify-content-center align-items-center flex-column p-4 rounded"
                    tag="div"
                  >
                    <h2><MDBIcon icon="user-friends" /></h2>
                    <p>Customers</p>
                  </MDBCardImage>
                  <MDBCardBody cascade className="text-center">
                    <MDBCardText>Total Customers</MDBCardText>
                    <hr />
                    <div className="text-center">
                      <MDBIcon
                        fab
                        icon="twitter"
                        className="tw-ic mr-3"
                        size="lg"
                      />
                      <MDBIcon
                        fab
                        icon="linkedin-in"
                        className="li-ic my-3"
                        size="lg"
                      />
                      <MDBIcon
                        fab
                        icon="facebook-f"
                        className="fb-ic ml-3"
                        size="lg"
                      />
                    </div>
                  </MDBCardBody>
                </MDBCard>
              </MDBCol>
            </div>
            <div class="col-sm" style={{ marginBottom: "5%" }}>
              <MDBCol col="4">
                <MDBCard>
                  <MDBCardImage
                    className="blue-gradient white-text d-flex justify-content-center align-items-center flex-column p-4 rounded"
                    tag="div"
                  >
                    <h2><MDBIcon icon="user-check" /></h2>
                    <p>Confirmed</p>
                  </MDBCardImage>
                  <MDBCardBody cascade className="text-center">
                    <MDBCardText>Confirmed orders</MDBCardText>
                    <hr />
                    <div className="text-center">
                      <MDBIcon
                        fab
                        icon="twitter"
                        className="tw-ic mr-3"
                        size="lg"
                      />
                      <MDBIcon
                        fab
                        icon="linkedin-in"
                        className="li-ic my-3"
                        size="lg"
                      />
                      <MDBIcon
                        fab
                        icon="facebook-f"
                        className="fb-ic ml-3"
                        size="lg"
                      />
                    </div>
                  </MDBCardBody>
                </MDBCard>
              </MDBCol>
            </div>
            <div class="col-sm" style={{ marginBottom: "5%" }}>
              <MDBCol col="4">
                <MDBCard>
                  <MDBCardImage
                    className="peach-gradient white-text d-flex justify-content-center align-items-center flex-column p-4 rounded"
                    tag="div"
                  >
                    <h2><MDBIcon icon="users-cog" /></h2>
                    <p>Panding</p>
                  </MDBCardImage>
                  <MDBCardBody cascade className="text-center">
                    <MDBCardText>Panding Orders</MDBCardText>
                    <hr />
                    <div className="text-center">
                      <MDBIcon
                        fab
                        icon="twitter"
                        className="tw-ic mr-3"
                        size="lg"
                      />
                      <MDBIcon
                        fab
                        icon="linkedin-in"
                        className="li-ic my-3"
                        size="lg"
                      />
                      <MDBIcon
                        fab
                        icon="facebook-f"
                        className="fb-ic ml-3"
                        size="lg"
                      />
                    </div>
                  </MDBCardBody>
                </MDBCard>
              </MDBCol>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default Userdashboard;
