import React, { Component } from 'react';
import Userdata from './userdata/Userdata';

class Userside extends Component {

  render() { 
    return <div>
      <Userdata/>
    </div>
  }
}
 
export default Userside;