import React, { Component } from "react";
import "./Userprofile.scss";
import { MDBBtn } from "mdbreact";
import Usernavbar from '../usernavbar/Usernavbar';

class Userprofile extends Component {
  render() {
    return (<div>
        <Usernavbar/>
      <div id="user-profile-top-padding">
        <div className="container bootstrap snippets bootdey">
          <div className="panel-body inf-content">
            <div className="row">
              <div className="col-md-4">
                <img
                  alt=""
                  style={{ width: "300px" }}
                  title=""
                  className="img-circle img-thumbnail isTooltip"
                  src="https://bootdey.com/img/Content/avatar/avatar7.png"
                  data-original-title="Usuario"
                />
                <div classNameName="row text-center">
                  <form className="md-form">
                    <span classNameName="col-md-12">
                      <input type="file" id="myFile" name="filename" />
                    </span>
                    <br />
                    <br />
                    <span
                      style={{ marginLeft: "20%" }}
                      classNameName="col-md-12 text-center"
                    >
                      <MDBBtn gradient="purple" type="submit">
                        submit
                      </MDBBtn>
                    </span>
                  </form>
                </div>
                <ul title="Ratings" className="list-inline ratings text-center">
                  <li>
                    <a href="#">
                      <span className="glyphicon glyphicon-star"></span>
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <span className="glyphicon glyphicon-star"></span>
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <span className="glyphicon glyphicon-star"></span>
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <span className="glyphicon glyphicon-star"></span>
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <span className="glyphicon glyphicon-star"></span>
                    </a>
                  </li>
                </ul>
              </div>
              <div className="col-md-6">
                <div className="table-responsive">
                  <table className="table table-user-information">
                    <tbody>
                      <tr>
                        <td>
                          <strong className="user-profile-text">
                            <span className="glyphicon glyphicon-asterisk text-primary"></span>
                            Identificacion
                          </strong>
                        </td>
                        <td className="text-primary"></td>
                      </tr>
                      <tr>
                        <td>
                          <strong className="user-profile-text">
                            <span className="glyphicon glyphicon-user  text-primary"></span>
                            Owner Name
                          </strong>
                        </td>
                        <td className="text-dark">UserName</td>
                      </tr>
                      <tr>
                        <td>
                          <strong className="user-profile-text">
                            <span className="glyphicon glyphicon-cloud text-primary"></span>
                            Phone Number
                          </strong>
                        </td>
                        <td className="text-dark">0314253846</td>
                      </tr>

                      <tr>
                        <td>
                          <strong className="user-profile-text">
                            <span className="glyphicon glyphicon-bookmark text-primary"></span>
                            Shop Adress
                          </strong>
                        </td>
                        <td className="text-dark">
                          house Number # 3321 street Number 14,koohinoor city
                        </td>
                      </tr>

                      <tr>
                        <td>
                          <strong className="user-profile-text">
                            <span className="glyphicon glyphicon-eye-open text-primary"></span>
                            Status
                          </strong>
                        </td>
                        <td className="text-dark">Verified</td>
                      </tr>

                      <tr>
                        <td>
                          <strong className="user-profile-text">
                            <span className="glyphicon glyphicon-calendar text-primary"></span>
                            Member Since
                          </strong>
                        </td>
                        <td className="text-dark">20 jul 2020</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      </div>
    );
  }
}

export default Userprofile;
