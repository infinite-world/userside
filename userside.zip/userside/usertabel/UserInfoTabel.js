import React from "react";
import { MDBCol, MDBIcon } from "mdbreact";
import Usernavbar from "../usernavbar/Usernavbar";

const SearchPage = () => {
  return (
    <div>
      <Usernavbar />
      <diV style={{ marginLeft: "3%" }}>
        <MDBCol md="4">
          <form className="form-inline mt-4 mb-4">
            <MDBIcon icon="search" />
            <input
              className="form-control form-control-sm ml-3 w-75"
              type="text"
              placeholder="Search"
              aria-label="Search"
            />
          </form>
        </MDBCol>
      </diV>
    </div>
  );
};

export default SearchPage;
