import React, { Component } from "react";
import "./ShalwarKameez.scss";
import { MDBBtn,MDBIcon } from "mdbreact";

class ShalwarKameez extends Component {
  render() {
    return (
      <div>
        <form>
          <div className="form-row">
            <div className="form-group col-md-4">
              
              <label for="inputEmail4" className="all-extra-text-class">
               Name
                <span>
                  <br />
                  نام
                </span>
              </label>
              <input
                style={{ borderRadius: "20px" }}
                type="text"
                className="form-control"
                placeholder="Search"
                required
              />
            </div>
            <div className="form-group col-md-4">
              <label for="inputEmail4" className="all-extra-text-class">
                Phone Number
                <span>
                  <br />
                  فون نمبر
                </span>
              </label>
              <input
                style={{ borderRadius: "20px" }}
                type="Number"
                className="form-control"
                placeholder="Phone Number"
                required
              />
            </div>
            <div className="form-group col-md-4">
              <label for="inputPassword4" className="all-extra-text-class">
                City
                <span>
                  <br /> شہر
                </span>
              </label>
              <input
                style={{ borderRadius: "20px" }}
                type="password"
                className="form-control"
                id="inputPassword4"
                placeholder="Password"
                required
              />
            </div>
          </div>
          <div className="form-group">
            <label for="inputAddress" className="all-extra-text-class">
              Address
              <span>
                <br />
                پتہ
              </span>
            </label>
            <input
              style={{ borderRadius: "20px" }}
              type="text"
              className="form-control"
              id="inputAddress"
              placeholder="Complete Adress"
              required
            />
          </div>

          {/* complete one row containing 4 columns */}

          <div className="form-row">
            <div className="form-group col-md-3">
              <label for="inputPassword4" className="all-extra-text-class">
                loose-fitting trouser
                <span>
                  <br /> شلوار لمبائی
                </span>
              </label>
              <input
                type="text"
                className="form-control"
                id="inputCity"
                style={{ borderRadius: "20px" }}
              />
            </div>
            <div className="form-group col-md-3">
              <label for="inputState" className="all-extra-text-class">
                Suit Surrounding
                <span>
                  <br />
                  گھیرا
                </span>
              </label>
              <select id="inputState" className="form-control">
                <option selected>Stright (سیدھا)</option>
                <option selected>Round (گول)</option>
              </select>
            </div>
            <div className="form-group col-md-3">
              <label for="inputState" className="all-extra-text-class">
                Suit Surrounding
                <span>
                  <br />
                  گھیرا
                </span>
              </label>
              <input
                type="text"
                className="form-control"
                id="inputZip"
                style={{ borderRadius: "20px" }}
              />
            </div>
            <div className="form-group col-md-3">
              <label for="inputZip" className="all-extra-text-class">
                shoulder
                <span>
                  <br />
                  کندھا
                </span>
              </label>
              <input
                type="text"
                className="form-control"
                id="inputZip"
                style={{ borderRadius: "20px" }}
              />
            </div>
          </div>

          {/* End of this row containing 4 columns */}

          {/* complete second row containing 4 columns */}

          <div className="form-row">
            <div className="form-group col-md-3">
              <label for="inputPassword4" className="all-extra-text-class">
                Neck Round
                <span>
                  <br />
                  گلہ
                </span>
              </label>
              <input
                type="text"
                className="form-control"
                id="inputCity"
                style={{ borderRadius: "20px" }}
              />
            </div>
            <div className="form-group col-md-3">
              <label for="inputState" className="all-extra-text-class">
                Teera
                <span>
                  <br />
                  تیرا
                </span>
              </label>
              <input
                type="text"
                className="form-control"
                id="inputCity"
                style={{ borderRadius: "20px" }}
              />
            </div>
            <div className="form-group col-md-3">
              <label for="inputState" className="all-extra-text-class">
                Arm
                <span>
                  <br />
                  بازو
                </span>
              </label>
              <input
                type="text"
                className="form-control"
                id="inputZip"
                style={{ borderRadius: "20px" }}
              />
            </div>
            <div className="form-group col-md-3">
              <label for="inputZip" className="all-extra-text-class">
                Waist
                <span>
                  <br />
                  کمر
                </span>
              </label>
              <input
                type="text"
                className="form-control"
                id="inputZip"
                style={{ borderRadius: "20px" }}
              />
            </div>
          </div>

          {/* End of this row containing 4 columns */}

          {/* complete Third row containing 4 columns */}

          <div className="form-row">
            <div className="form-group col-md-3">
              <label for="inputPassword4" className="all-extra-text-class">
                Breast
                <span>
                  <br />
                  چھاتی
                </span>
              </label>
              <input
                type="text"
                className="form-control"
                id="inputCity"
                style={{ borderRadius: "20px" }}
              />
            </div>
            <div className="form-group col-md-3">
              <label for="inputState" className="all-extra-text-class">
                Length
                <span>
                  <br />
                  لمبائی
                </span>
              </label>
              <input
                type="text"
                className="form-control"
                id="inputCity"
                style={{ borderRadius: "20px" }}
              />
            </div>
            <div className="form-group col-md-3">
              <label for="inputState" className="all-extra-text-class">
                bandage
                <span>
                  <br />
                  پٹی
                </span>
              </label>
              <input
                type="text"
                className="form-control"
                id="inputZip"
                style={{ borderRadius: "20px" }}
              />
            </div>
            <div className="form-group col-md-3">
              <label for="inputZip" className="all-extra-text-class">
                Kaff
                <span>
                  <br />
                  کف
                </span>
              </label>
              <input
                type="text"
                className="form-control"
                id="inputZip"
                style={{ borderRadius: "20px" }}
              />
            </div>
          </div>

          {/* End of this row containing 4 columns */}

          {/* complete Forth row containing 4 columns */}

          <div className="form-row">
            <div className="form-group col-md-3">
              <label for="inputPassword4" className="all-extra-text-class">
                Shalwar pocket
                <span>
                  <br />
                  شلوار جیب
                </span>
              </label>
              <input
                type="text"
                className="form-control"
                id="inputCity"
                style={{ borderRadius: "20px" }}
              />
            </div>
            <div className="form-group col-md-3">
              <label for="inputState" className="all-extra-text-class">
                Front pocket
                <span>
                  <br />
                  فرنٹ جیب
                </span>
              </label>
              <input
                type="text"
                className="form-control"
                id="inputCity"
                style={{ borderRadius: "20px" }}
              />
            </div>
            <div className="form-group col-md-3">
              <label for="inputState" className="all-extra-text-class">
                Side pocket
                <span>
                  <br />
                  سائیڈ جیب
                </span>
              </label>
              <input
                type="text"
                className="form-control"
                id="inputZip"
                style={{ borderRadius: "20px" }}
              />
            </div>
            <div className="form-group col-md-3">
              <label for="inputZip" className="all-extra-text-class">
                Ben
                <span>
                  <br />
                  بین
                </span>
              </label>
              <input
                type="text"
                className="form-control"
                id="inputZip"
                style={{ borderRadius: "20px" }}
              />
            </div>
          </div>

          {/* End of this row containing 4 columns */}
          <div className="form-group">
            <label for="inputAddress" className="all-extra-text-class">
              Description
              <span>
                <br />
                تفصیل
              </span>
            </label>
            <input
              style={{ borderRadius: "20px" }}
              type="text"
              className="form-control"
              id="inputAddress"
              placeholder="Complete Customer Description"
              required
            />
          </div>

          {/* Description row ended */}

          <div className="form-group">
            <div className="form-check">
              <input
                className="form-check-input"
                type="checkbox"
                id="gridCheck"
                style={{ borderRadius: "20px" }}
              />
              <label className="form-check-label" for="gridCheck">
                Check me out
              </label>
            </div>
          </div>
          <MDBBtn gradient="purple">Submit</MDBBtn>
        </form>
      </div>
    );
  }
}

export default ShalwarKameez;
