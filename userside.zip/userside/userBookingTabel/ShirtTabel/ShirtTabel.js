import React, { Component } from "react";
import { MDBBtn } from "mdbreact";

class ShirtTabel extends Component {
  render() {
    return (
      <div>
        <form>
          <div className="form-row">
            <div className="form-group col-md-4">
              <label for="inputEmail4" className="all-extra-text-class">
                Name
                <span>
                  <br />
                  نام
                </span>
              </label>
              <input
                style={{ borderRadius: "20px" }}
                type="text"
                className="form-control"
                placeholder="search"
                required
              />
            </div>
            <div className="form-group col-md-4">
              <label for="inputEmail4" className="all-extra-text-class">
                Phone Number
                <span>
                  <br />
                  فون نمبر
                </span>
              </label>
              <input
                style={{ borderRadius: "20px" }}
                type="Number"
                className="form-control"
                placeholder="Phone Number"
                required
              />
            </div>
            <div className="form-group col-md-4">
              <label for="inputPassword4" className="all-extra-text-class">
                City
                <span>
                  <br /> شہر
                </span>
              </label>
              <input
                style={{ borderRadius: "20px" }}
                type="password"
                className="form-control"
                id="inputPassword4"
                placeholder="Password"
                required
              />
            </div>
          </div>
          <div className="form-group">
            <label for="inputAddress" className="all-extra-text-class">
              Address
              <span>
                <br />
                پتہ
              </span>
            </label>
            <input
              style={{ borderRadius: "20px" }}
              type="text"
              className="form-control"
              id="inputAddress"
              placeholder="Complete Adress"
              required
            />
          </div>

          {/* complete one row containing 4 columns */}

          <div className="form-row">
            <div className="form-group col-md-3">
              <label for="inputState" className="all-extra-text-class">
                Suit Surrounding
                <span>
                  <br />
                  گھیرا
                </span>
              </label>
              <select id="inputState" className="form-control">
                <option selected>Stright (سیدھا)</option>
                <option selected>Round (گول)</option>
              </select>
            </div>
            <div className="form-group col-md-3">
              <label for="inputState" className="all-extra-text-class">
                Kaff
                <span>
                  <br />
                  کف
                </span>
              </label>
              <input
                type="text"
                className="form-control"
                id="inputZip"
                style={{ borderRadius: "20px" }}
              />
            </div>
            <div className="form-group col-md-3">
              <label for="inputState" className="all-extra-text-class">
                Preparation
                <span>
                  <br />
                  تیاری
                </span>
              </label>
              <input
                type="text"
                className="form-control"
                id="inputZip"
                style={{ borderRadius: "20px" }}
              />
            </div>
            <div className="form-group col-md-3">
              <label for="inputZip" className="all-extra-text-class">
                shoulder
                <span>
                  <br />
                  کندھا
                </span>
              </label>
              <input
                type="text"
                className="form-control"
                id="inputZip"
                style={{ borderRadius: "20px" }}
              />
            </div>
          </div>

          {/* End of this row containing 4 columns */}

          {/* complete second row containing 4 columns */}

          <div className="form-row">
            <div className="form-group col-md-3">
              <label for="inputPassword4" className="all-extra-text-class">
                Neck Round
                <span>
                  <br />
                  گلہ
                </span>
              </label>
              <input
                type="text"
                className="form-control"
                id="inputCity"
                style={{ borderRadius: "20px" }}
              />
            </div>
            <div className="form-group col-md-3">
              <label for="inputState" className="all-extra-text-class">
                Teera
                <span>
                  <br />
                  تیرا
                </span>
              </label>
              <input
                type="text"
                className="form-control"
                id="inputCity"
                style={{ borderRadius: "20px" }}
              />
            </div>
            <div className="form-group col-md-3">
              <label for="inputState" className="all-extra-text-class">
                Arm
                <span>
                  <br />
                  بازو
                </span>
              </label>
              <input
                type="text"
                className="form-control"
                id="inputZip"
                style={{ borderRadius: "20px" }}
              />
            </div>
            <div className="form-group col-md-3">
              <label for="inputZip" className="all-extra-text-class">
                Waist
                <span>
                  <br />
                  کمر
                </span>
              </label>
              <input
                type="text"
                className="form-control"
                id="inputZip"
                style={{ borderRadius: "20px" }}
              />
            </div>
          </div>

          {/* End of this row containing 4 columns */}

          {/* complete Third row containing 4 columns */}

          <div className="form-row">
            <div className="form-group col-md-3">
              <label for="inputPassword4" className="all-extra-text-class">
                Breast
                <span>
                  <br />
                  چھاتی
                </span>
              </label>
              <input
                type="text"
                className="form-control"
                id="inputCity"
                style={{ borderRadius: "20px" }}
              />
            </div>
            <div className="form-group col-md-3">
              <label for="inputState" className="all-extra-text-class">
                Length
                <span>
                  <br />
                  لمبائی
                </span>
              </label>
              <input
                type="text"
                className="form-control"
                id="inputCity"
                style={{ borderRadius: "20px" }}
              />
            </div>

            <div className="form-group col-md-6">
              <label for="inputState" className="all-extra-text-class">
                Front pocket
                <span>
                  <br />
                  فرنٹ جیب
                </span>
              </label>
              <select id="inputState" className="form-control">
                <option selected>Stright (سیدھا)</option>
                <option selected>Round (گول)</option>
              </select>
            </div>
          </div>

          {/* End of this row containing 4 columns */}

          <div className="form-group">
            <label for="inputAddress" className="all-extra-text-class">
              Description
              <span>
                <br />
                تفصیل
              </span>
            </label>
            <input
              style={{ borderRadius: "20px" }}
              type="text"
              className="form-control"
              id="inputAddress"
              placeholder="Complete Customer Description"
              required
            />
          </div>

          {/* Description row ended */}

          <div className="form-group">
            <div className="form-check">
              <input
                className="form-check-input"
                type="checkbox"
                id="gridCheck"
                style={{ borderRadius: "20px" }}
              />
              <label className="form-check-label" for="gridCheck">
                Check me out
              </label>
            </div>
          </div>
          <MDBBtn gradient="purple">Submit</MDBBtn>
        </form>
      </div>
    );
  }
}

export default ShirtTabel;
