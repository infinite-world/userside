import React, { Component } from "react";
import ShalwarKameez from "./ShalwarKameezTabel/ShalwarKameez";
import Usernavbar from "../usernavbar/Usernavbar";
import "./BookingTabel.scss";
import PantCoatTabel from "./PantCoatTabel/PantCoatTabel";
import ShirtTabel from "./ShirtTabel/ShirtTabel";
import ShirwaniTabel from "./ShairwaniTabel/ShirwaniTabel";
import { MDBBtn, MDBIcon, MDBJumbotron, MDBContainer } from "mdbreact";

class UserBookingTabel extends Component {
  render() {
    return (
      <div>
        <Usernavbar />
        <div className="container">
          <br />
          <br />

        <div class="jumbotron jumbotron-fluid grey lighten-5">
          <ul className="nav-tabs nav nav-justified">
            <li
              className="nav-item"
              style={{
                backgroundColor: "grey lighten-5 ",
             
              }}
            >
              <a
                href="#profile"
                className="nav-link"
                data-toggle="tab"
                style={{ color: "black",fontFamily:"vernada",fontWeight:"bold",color:"grey"}}
              >
                ShalwarKameez (شلوار قمیض)
              </a>
            </li>
            <li
              className="nav-item"
              style={{
                backgroundColor: "grey lighten-5 ",
             
              }}
            >
              <a
                href="#notification"
                className="nav-link"
                data-toggle="tab"
                style={{ color: "black",fontFamily:"vernada",fontWeight:"bold",color:"grey"}}
              >
                PantCoat (پینٹ کوٹ)
              </a>
            </li>
            <li
              className="nav-item"
              style={{
                backgroundColor: "grey lighten-5 ",
             
              }}
            >
              <a
                href="#message"
                className="nav-link"
                data-toggle="tab"
                style={{ color: "black",fontFamily:"vernada",fontWeight:"bold",color:"grey"}}
              >
                Sherwani (شروانی)
              </a>
            </li>
            <li
              className="nav-item"
              style={{
                backgroundColor: "grey lighten-5 ",
             
              }}
            >
              <a
                href="#logout"
                className="nav-link"
                data-toggle="tab"
                style={{ color: "black",fontFamily:"vernada",fontWeight:"bold",color:"grey"}}
              >
                Shirt (شرٹ)  
              </a>
            </li>
          </ul>
          </div>
          {/* data contents are here  */}

          <div className="tab-content container">
            <div className="tab-pane" id="profile">
              <br />
              <h1 className="shalwar-kameez-text"> Shalwar Kameez <MDBIcon icon="male" /></h1>
              <br />
              <ShalwarKameez />
            </div>
            {/* Next content tab */}
            <div className="tab-pane" id="notification">
              <br />
              <h1 className="shalwar-kameez-text"> Pant Coat <MDBIcon icon="user-tie" /></h1>
              <br />
              <PantCoatTabel />
            </div>
            {/* Next content tab */}
            <div className="tab-pane" id="message">
              <br />
              <h1 className="shalwar-kameez-text"> Sherwani <MDBIcon icon="male" /></h1>
              <br />
              <ShirwaniTabel />
            </div>
            {/* Next content tab */}
            <div className="tab-pane" id="logout">
              <br />
              <h1 className="shalwar-kameez-text"> Shirt <MDBIcon icon="tshirt" /> </h1>
              <br />
              <ShirtTabel />
            </div>
          </div>
        </div>
        
      </div>
    );
  }
}

export default UserBookingTabel;
