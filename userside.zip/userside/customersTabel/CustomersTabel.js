import React, { Fragment, Component } from "react";
import {
  MDBTable,
  MDBTableBody,
  MDBTableHead,
  MDBBtn,
  MDBIcon,
  MDBContainer,
  MDBJumbotron,
  MDBCol,
} from "mdbreact";
import Usernavbar from "../usernavbar/Usernavbar";

import "./Customers.scss";

class UserTable extends Component {
  render() {
    return (
      <div>
        <Usernavbar />
        <React.Fragment>
          <MDBContainer className="mt-2 text-center">
            <MDBCol>
              <MDBJumbotron>
              <MDBBtn gradient="blue">
                <h2
                  className="h1 display-4"
                  style={{
                    textShadow: "2px 2px 4px #000000",
                
                    color: "white",
                  }}
                >
                  Customers گاہک
                </h2>
                </MDBBtn>
              </MDBJumbotron>
            </MDBCol>
          </MDBContainer>
          <form
            class="form-inline md-form mr-auto mb-4"
            style={{ marginLeft: "11px" }}
          >
            <input
              class="form-control mr-sm-2"
              type="text"
              placeholder="Search"
              aria-label="Search"
            />
            <button
              class="btn aqua-gradient btn-rounded btn-sm my-0"
              type="submit"
              style={{ textShadow: "2px 2px 4px #000000" }}
            >
              Search
            </button>
          </form>
          {/* Table content satrt */}

          <div id="userTable-full-cover1">
            <MDBTable striped id="user-tabel-cover">
              <MDBTableHead>
                <tr id="header-top-row">
                  <th className="header-color">
                    <MDBIcon icon="file-signature" /> Name
                  </th>
                  <th className="header-color">
                    <MDBIcon icon="mobile-alt" /> Number
                  </th>
                  <th className="header-color">
                    <MDBIcon far icon="address-card" /> Adress
                  </th>
                  <th className="header-color">
                    <MDBIcon far icon="calendar-alt" /> Date
                  </th>
                  <th className="header-color">
                    <MDBIcon far icon="check-circle" /> Completed
                  </th>
                  <th className="header-color"></th>
                  <th className="header-color">
                    <MDBIcon fab icon="galactic-republic" /> Action
                  </th>
                  <th className="header-color"></th>
                </tr>
              </MDBTableHead>
              <MDBTableBody>
                {/* First Completed Row */}

                <tr>
                  <td>Ibtisam Mirza</td>
                  <td>03241575728</td>
                  <td>D-ground,Mdina Town Jaranwala</td>
                  <td>12/10/2020</td>
                  <td>15 suits</td>
                  <td>
                    <MDBBtn
                      gradient="blue"
                      style={{ textShadow: "2px 2px 4px grey" }}
                    >
                      <MDBIcon far icon="eye" />
                    </MDBBtn>
                  </td>
                  <td>
                    <MDBBtn
                      gradient="purple"
                      style={{ textShadow: "2px 2px 4px #000000" }}
                    >
                      EDIT
                    </MDBBtn>
                  </td>
                  <td>
                    <MDBBtn
                      gradient="peach"
                      style={{ textShadow: "2px 2px 4px #000000" }}
                    >
                      <MDBIcon far icon="trash-alt" />
                    </MDBBtn>
                  </td>
                </tr>

                {/* First Row ended */}
              </MDBTableBody>
            </MDBTable>
          </div>
          {/* Table content finish */}
        </React.Fragment>
      </div>
    );
  }
}

export default UserTable;
