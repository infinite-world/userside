import React, { Component } from "react";
import "./Userdata.scss";
import Usernavbar from "../usernavbar/Usernavbar";
import Userdashboard from "../userdashboard/Userdashboard";
import Usergraphs from "../usergraphs/Usergraphs";
import Userfooter from "../userfooter/Userfooter";

class Userside extends Component {
  render() {
    return (
      <div>
        <Usernavbar />
        <Userdashboard />
        <Usergraphs />
        <Userfooter />
      </div>
    );
  }
}

export default Userside;
